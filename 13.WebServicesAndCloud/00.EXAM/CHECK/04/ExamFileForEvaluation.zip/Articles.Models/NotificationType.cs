﻿namespace Articles.Models
{
    public enum NotificationType
    {
        GameJoined,
        Won,
        Lost

    }
}
