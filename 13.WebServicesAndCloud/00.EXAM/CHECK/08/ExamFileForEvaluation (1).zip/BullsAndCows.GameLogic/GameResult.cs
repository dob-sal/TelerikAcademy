﻿namespace BullsAndCows.GameLogic
{
    public enum GameResult
    {
        NotFinished,
        WonByRedPlayer,
        WonByBluePlayer,
    }
}
