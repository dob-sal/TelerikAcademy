﻿namespace BullsAndCows.Models
{
    public enum NotificationState
    {
        Read = 0, 
        Unread = 1
    }
}
