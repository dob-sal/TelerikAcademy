﻿namespace BullsAndCows.Web.DataModels
{
    public class HighScoreBoardDataModel
    {
        public string Player { get; set; }

        public int Rank { get; set; }
    }
}