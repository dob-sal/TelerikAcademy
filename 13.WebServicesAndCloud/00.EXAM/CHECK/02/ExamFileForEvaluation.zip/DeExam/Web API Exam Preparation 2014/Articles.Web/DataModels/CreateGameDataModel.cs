﻿namespace BullsAndCows.Web.Controllers
{
    public class CreateGameDataModel
    {
        public string Name { get; set; }

        public string Number { get; set; }
    }
}
