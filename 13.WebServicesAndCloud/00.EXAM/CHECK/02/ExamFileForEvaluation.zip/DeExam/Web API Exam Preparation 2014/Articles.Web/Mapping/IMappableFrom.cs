﻿namespace BullsAndCows.Web.Mapping
{
    public interface IMappableFrom<T>
    {
    }
}
